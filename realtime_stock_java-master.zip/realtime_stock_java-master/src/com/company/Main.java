package com.company;

import com.company.model.StockData;
import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.net.ssl.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

public class Main {

    final static Logger logger = Logger.getLogger(Main.class);
    //public static final String URL_SOCKET = "http://banggiagateway.vpbs.com.vn:8080/REALTIME_PS_MOBILE";
    public static final String URL_SOCKET = "https://sodatafeed.vps.com.vn";
    Socket mSocket;
    public static HomeGui homeGui;

    public static void main(String[] args) {
        Main main = new Main();
        main.socketInit();
        main.onEventSocket();

        main.initRetrofit();
    }

    private void socketInit() {

        try {
            IO.Options opts = new IO.Options();
            SSLContext mySSLContext = SSLContext.getInstance("TLS");
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new java.security.cert.X509Certificate[]{};
                }

                public void checkClientTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }

                public void checkServerTrusted(X509Certificate[] chain,
                                               String authType) throws CertificateException {
                }
            }};

            mySSLContext.init(null, trustAllCerts, null);

            HostnameVerifier myHostnameVerifier = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            opts = new IO.Options();
            opts.sslContext = mySSLContext;
            opts.hostnameVerifier = myHostnameVerifier;

            mSocket = IO.socket(URL_SOCKET, opts);

            mSocket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    homeGui.updateStatus("connect","i");
                    logger.info("EVENT_OPEN");
                }
            }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logger.info("EVENT_CLOSE");
                    homeGui.updateStatus("close","d");
                }
            }).on(Socket.EVENT_ERROR, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    logger.info("EVENT_ERROR " + args[0].toString());
                    homeGui.updateStatus("error " + args[0].toString(),"d");
                }
            });


        } catch (Exception e) {
            logger.error("Exception " + e);
        }

    }

    private void onEventSocket() {
        mSocket.on("board", new Emitter.Listener() {
            @Override
            public void call(Object... objects) {
                logger.info("BOARD CHANEL : " + objects[0].toString());
            }
        }).on("stockps", new Emitter.Listener() {
            @Override
            public void call(Object... objects) {
                logger.info("STOCKPS CHANEL : " + objects[0].toString());
            }
        }).on("index", new Emitter.Listener() {
            @Override
            public void call(Object... objects) {
                //logger.info("INDEX CHANEL : " + objects[0].toString());
            }
        }).on("boardps", new Emitter.Listener() {
            @Override
            public void call(Object... objects) {
                logger.info("BOARDPS CHANEL : " + objects[0].toString());
            }
        }).on("stock", new Emitter.Listener() {
            @Override
            public void call(Object... objects) {
                logger.info("STOCK CHANEL : " + objects[0].toString());
                homeGui.updateDataLastValue(objects[0].toString());
            }
        });

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("action", "join");
            jsonObject.put("list", "FLC");
            mSocket.emit("regs", jsonObject.toString());

            // ["regs","{\"action\":\"join\",\"list\":\"GB05F1909,GB05F1912,GB05F2003,VN30F1909,VN30F1910,VN30F1912,VN30F2003\"}"]
            // 42["regs","{\"action\":\"join\",\"list\":\"AAA,AAM,ABT,ACC,ACL,ADS,AGF,AGM,AGR,AMD,ANV,APC,APG,ASM,ASP,AST,ATG,BBC,BCE,BCG,BFC,BHN,BIC,BID,BMC,BMI,BMP,BRC,BSI,BTP,BTT,BVH,BWE,C32,C47,CAV,CCI,CCL,CDC,CEE,CFPT1901,CFPT1902,CFPT1903,CHP,CHPG1901,CHPG1902,CHPG1903,CHPG1904,CHPG1905,CIG,CII,CLC,CLG,CLL,CLW,CMBB1901,CMBB1902,CMG,CMV,CMWG1901,CMWG1902,CMWG1903,CMWG1904,CMX,CNG,COM,CPNJ1901,CRC,CRE,CSM,CSV,CTD,CTF,CTG,CTI,CTS,CVNM1901,CVT,D2D,DAG,DAH,DAT,DBC,DBD,DCL,DCM,DGW,DHA,DHC,DHG,DHM,DIC,DIG,DLG,DMC,DPG,DPM,DPR,DQC,DRC,DRH,DRL,DSN,DTA,DTL,DTT,DVP,DXG,DXV,E1VFVN30,EIB,ELC,EMC,EVE,EVG,FCM,FCN,FDC,FIR,FIT,FLC,FMC,FPT,FRT,FTM,FTS,FUCTVGF1,FUCTVGF2,FUCVREIT,FUESSV50,GAB,GAS,GDT,GEX,GIL,GMC,GMD,GSP,GTA,GTN,HAG,HAH,HAI,HAP,HAR,HAS,HAX,HBC,HCD,HCM,HDB,HDC,HDG,HHS,HID,HII,HLG,HMC,HNG,HOT,HPG,HPX,HQC,HRC,HSG,HSL,HT1,HTI,HTL,HTN,HTT,HTV,HU1,HU3,HUB,HVG,HVH,HVN,HVX,IBC,IDI,IJC,ILB,IMP,ITA,ITC,ITD,JVC,KAC,KBC,KDC,KDH,KHP,KMR,KOS,KPF,KSB,KSH,L10,LAF,LBM,LCG,LCM,LDG,LEC,LGC,LGL,LHG,LIX,LM8,LMH,LSS,MBB,MCG,MCP,MDG,MHC,MSH,MSN,MWG,NAF,NAV,NBB,NCT,NKG,NLG,NNC,NSC,NT2,NTL,NVL,NVT,OGC,OPC,PAC,PAN,PC1,PDN,PDR,PET,PGC,PGD,PGI,PHC,PHR,PIT,PJT,PLP,PLX,PME,PMG,PNC,PNJ,POM,POW,PPC,PTB,PTC,PTL,PVD,PVT,PXI,PXS,PXT,QBS,QCG,RAL,RDP,REE,RIC,ROS,S4A,SAB,SAM,SAV,SBA,SBT,SBV,SC5,SCD,SCR,SCS,SFC,SFG,SFI,SGN,SGR,SGT,SHA,SHI,SHP,SII,SJD,SJF,SJS,SKG,SMA,SMB,SMC,SPM,SRC,SRF,SSC,SSI,ST8,STB,STG,STK,SVC,SVI,SVT,SZC,SZL,TAC,TBC,TCB,TCD,TCH,TCL,TCM,TCO,TCR,TCT,TDC,TDG,TDH,TDM,TDW,TEG,TGG,THG,THI,TIP,TIX,TLD,TLG,TLH,TMP,TMS,TMT,TN1,TNA,TNC,TNI,TNT,TPB,TPC,TRA,TRC,TS4,TSC,TTB,TTE,TTF,TV2,TVB,TVS,TVT,TYA,UDC,UIC,VAF,VCB,VCF,VCI,VDP,VDS,VFG,VGC,VHC,VHM,VIC,VID,VIP,VIS,VJC,VMD,VND,VNE,VNG,VNL,VNM,VNS,VOS,VPB,VPD,VPG,VPH,VPI,VPK,VPS,VRC,VRE,VSC,VSH,VSI,VTB,VTO,YBM,YEG\"}"]
        } catch (Exception e) {

        }


    }

    private void initRetrofit() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL_SOCKET+"/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        ApiService service = retrofit.create(ApiService.class);

        service.getStockList().enqueue(new Callback<List<StockData>>() {
            @Override
            public void onResponse(Call<List<StockData>> call, Response<List<StockData>> response) {
                homeGui = new HomeGui(response.body().get(0));
                mSocket.open();
            }

            @Override
            public void onFailure(Call<List<StockData>> call, Throwable throwable) {
                throwable.toString();
            }
        });
    }
}
