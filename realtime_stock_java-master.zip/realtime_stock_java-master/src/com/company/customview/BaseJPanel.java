package com.company.customview;

import javax.swing.*;
import java.awt.*;

public class BaseJPanel extends JPanel {
    public BaseJPanel() {

        this.setBackground(Color.decode("#000100"));
        this.setLayout(new GridBagLayout());
    }
}
