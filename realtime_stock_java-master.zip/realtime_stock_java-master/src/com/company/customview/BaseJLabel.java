package com.company.customview;

import javax.swing.*;
import java.awt.*;

public class BaseJLabel extends JLabel {
    public BaseJLabel(String text , String type) {
        super(text);
        //this.setVerticalAlignment(SwingConstants.CENTER);
        this.setForeground(Color.WHITE);
        this.setFont(new Font("Roboto-Regular", Font.PLAIN, 18));
       /* if (type.equals("right")){
            this.setAlignmentX(SwingConstants.RIGHT);
        }
        else {
            if (type.equals("left")){
                this.setAlignmentX(SwingConstants.LEFT);
            }
            else {
                this.setAlignmentX(SwingConstants.CENTER);
            }
        }*/
    }
}
