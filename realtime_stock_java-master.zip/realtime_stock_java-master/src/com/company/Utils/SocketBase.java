package com.company.Utils;


import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.util.Map;

public class SocketBase extends WebSocketClient {

    public SocketBase(URI serverUri , Draft draft ) {
        super( serverUri, draft );
    }

    public SocketBase(URI serverURI ) {
        super( serverURI );
    }

    public SocketBase(URI serverUri, Map<String, String> httpHeaders ) {
        super(serverUri, httpHeaders);
    }

    @Override
    public void onOpen( ServerHandshake handshakedata ) {
        send("[{\"_event\":\"bulk-subscribe\",\"tzID\":110,\"message\":\"pid-1057391:%%pid-1061443:%%pid-1057392:%%pid-1061410:%%pid-1061453:%%pid-41064:%%pid-995072:%%pid-41063:%%pid-41062:%%pid-169:%%pid-166:%%pid-172:%%pid-38015:%%pid-17940:%%pid-178:%%pid-40820:%%pid-2214:%%pid-1715:%%pid-8830:%%pid-8849:%%pid-13916:%%pid-1:%%pid-2:%%pid-3:%%pid-5:%%pid-1803:%%pid-27:%%pid-179:%%pid-995068:%%pid-8839:%%event-395966:%%event-395974:%%event-395975:%%event-395978:%%event-395976:%%event-395977:%%event-397036:%%isOpenExch-122:%%isOpenExch-72:%%isOpenExch-1:%%isOpenExch-21:%%isOpenExch-3:%%isOpenPair-8839:%%domain-52:\"}]");
        System.out.println( "opened connection" );
        // if you plan to refuse connection based on ip or httpfields overload: onWebsocketHandshakeReceivedAsClient
    }

    @Override
    public void onMessage( String message ) {
        System.out.println( "received: " + message );
    }

    @Override
    public void onClose( int code, String reason, boolean remote ) {
        // The codecodes are documented in class org.java_websocket.framing.CloseFrame
        System.out.println( "Connection closed by " + ( remote ? "remote peer" : "us" ) + " Code: " + code + " Reason: " + reason );
    }

    @Override
    public void onError( Exception ex ) {
        ex.printStackTrace();
        // if the error is fatal then onClose will be called additionally
        System.out.println( "onError: " );
    }
    }


