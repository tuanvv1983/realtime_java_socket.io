package com.company.Utils;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class UtilsFormat {
    public static String formatMoney(String _price) {
        DecimalFormatSymbols symbol = new DecimalFormatSymbols(Locale.ENGLISH);
        DecimalFormat formatter = new DecimalFormat("###,###,###,###",symbol);
        String money = "0";
        try {
            long number = Long.parseLong(_price);
            money = formatter.format(number);
        } catch (Exception e) {
        }
        return money;
    }
}
