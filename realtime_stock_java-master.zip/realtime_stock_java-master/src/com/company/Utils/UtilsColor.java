package com.company.Utils;

public class UtilsColor {
    public static String getcolor(String cl) {
        if (cl.equals("d"))
        {
            return "#ff0000";
        }

        if (cl.equals("i"))
        {
            return "#00ff00";
        }

        if (cl.equals("e"))
        {
            return "#ffd900";
        }

        if (cl.equals("c"))
        {
            return "#ff25ff";
        }

        if (cl.equals("f"))
        {
            return "#1eeeee";
        }

        return "#f0f0f0";
    }
}
