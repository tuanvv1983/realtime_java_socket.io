package com.company;


import com.company.Utils.SocketBase;
import org.apache.log4j.Logger;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.lang.reflect.Type;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MainInvest {
   // final static Logger logger = Logger.getLogger(MainInvest.class);
    public static void main(String[] args) {

        SocketBase c = null; // more about drafts here: http://github.com/TooTallNate/Java-WebSocket/wiki/Drafts
        try {
            Map<String, String > header = new HashMap<>();
            header.put("Accept-Encoding","gzip, deflate, br");
            header.put("Accept-Language","vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5");
            header.put("Cache-Control","no-cache");
            header.put("Connection","Upgrade");
            header.put("Host","stream33.forexpros.com");
            header.put("Origin","https://vn.investing.com");
            header.put("Pragma","no-cache");
            header.put("Sec-WebSocket-Extensions","permessage-deflate; client_max_window_bits");
            header.put("Sec-WebSocket-Key","GUJ5CUou5ZerOcniTQS45w==");
            header.put("Sec-WebSocket-Version","13");
            header.put("Upgrade","websocket");
            header.put("User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36");

            c = new SocketBase( new URI( "wss://stream25.forexpros.com/echo/366/3vb0benb/websocket"),header);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        c.connect();
       /* logger.info("Start");
        WebSocketClient client = new StandardWebSocketClient();

        WebSocketStompClient stompClient = new WebSocketStompClient(client);
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());

        StompSessionHandler sessionHandler = new StompSessionHandler() {
            @Override
            public void afterConnected(StompSession stompSession, StompHeaders stompHeaders) {
                logger.info("afterConnected");
            }

            @Override
            public void handleException(StompSession stompSession, StompCommand stompCommand, StompHeaders stompHeaders, byte[] bytes, Throwable throwable) {
                logger.error("handleException");
            }

            @Override
            public void handleTransportError(StompSession stompSession, Throwable throwable) {
                logger.error("handleTransportError");
            }

            @Override
            public Type getPayloadType(StompHeaders stompHeaders) {
                return null;
            }

            @Override
            public void handleFrame(StompHeaders stompHeaders, Object o) {
                logger.error("handleFrame");
            }
        };
        stompClient.connect("wss://stream25.forexpros.com/echo/366/3vb0benb/websocket", sessionHandler );*/
    }
}
