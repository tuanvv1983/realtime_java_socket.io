package com.company;

import com.company.Utils.UtilsColor;
import com.company.Utils.UtilsFormat;
import com.company.customview.BaseJLabel;
import com.company.customview.BaseJPanel;
import com.company.model.StockData;
import com.github.nkzawa.socketio.client.On;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Handler;

import static javax.swing.SwingConstants.WEST;

public class HomeGui {

    private JPanel panel0;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;
    private JPanel panel4;
    private JFrame mainFrame;
    BaseJLabel lbStatus;
    BaseJLabel lbPrice;
    BaseJLabel lbOT;
    BaseJLabel lbLastVolume;
    BaseJLabel lbSym;

    public HomeGui(StockData stockDataList)
    {
        mainFrame = new JFrame();
        mainFrame.setSize(400,120);
        mainFrame.setLayout(new GridLayout(3, 1));
        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });
        mainFrame.setAlwaysOnTop (true);


        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.CENTER;
        gbc.weightx = 1;
        gbc.weighty = 1;



        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,10,0,0);
        panel1 = new BaseJPanel();
        panel1.add(new BaseJLabel("Mã","left"),gbc);

        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0,0,0,0);
        panel1.add(new BaseJLabel("Giá",""),gbc);
        panel1.add(new BaseJLabel("+/-",""),gbc);
        panel1.add(new BaseJLabel("KL",""),gbc);
        panel1.add(new BaseJLabel("Trần",""),gbc);
        panel1.add(new BaseJLabel("Sàn",""),gbc);
        panel1.add(new BaseJLabel("TC",""),gbc);


        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0,10,0,0);
        panel2 = new BaseJPanel();
        lbSym = new BaseJLabel(stockDataList.getSym(),"left");
        lbSym.setForeground(Color.decode(UtilsColor.getcolor(stockDataList.getCl())));
        panel2.add(lbSym ,gbc);

        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0,0,0,10);
        lbPrice = new BaseJLabel(stockDataList.getLastPrice().toString(),"right");
        lbPrice.setForeground(Color.decode(UtilsColor.getcolor(stockDataList.getCl())));
        panel2.add(lbPrice,gbc);

        lbOT = new BaseJLabel(stockDataList.getOt(),"right");
        lbOT.setForeground(Color.decode(UtilsColor.getcolor(stockDataList.getCl())));
        panel2.add(lbOT,gbc);

        lbLastVolume =new BaseJLabel(UtilsFormat.formatMoney(stockDataList.getLastVolume().toString()),"right");
        lbLastVolume.setForeground(Color.decode(UtilsColor.getcolor(stockDataList.getCl())));
        panel2.add(lbLastVolume,gbc);

        BaseJLabel lbC =new BaseJLabel(stockDataList.getC().toString(),"right");
        lbC.setForeground(Color.decode(UtilsColor.getcolor("c")));
        panel2.add(lbC,gbc);


        BaseJLabel lbF =new BaseJLabel(stockDataList.getF().toString(),"right");
        lbF.setForeground(Color.decode(UtilsColor.getcolor("f")));
        panel2.add(lbF,gbc);

        BaseJLabel lbR =new BaseJLabel(stockDataList.getR().toString(),"right");
        lbR.setForeground(Color.decode(UtilsColor.getcolor("e")));
        panel2.add(lbR,gbc);


        panel3 = new BaseJPanel();
        lbStatus = new BaseJLabel("SocketIo","right");
        panel3.add(lbStatus,gbc);

  /*      panel3 = new BaseJPanel();
        panel3.add(new BaseJLabel("B_G3",""),gbc);
        panel3.add(new BaseJLabel("B_KL3",""),gbc);
        panel3.add(new BaseJLabel("B_G2",""),gbc);
        panel3.add(new BaseJLabel("B_KL2",""),gbc);
        panel3.add(new BaseJLabel("B_G1",""),gbc);
        panel3.add(new BaseJLabel("B_KL1",""),gbc);

        panel4 = new BaseJPanel();
        panel4.add(new BaseJLabel("S_G3",""),gbc);
        panel4.add(new BaseJLabel("S_KL3",""),gbc);
        panel4.add(new BaseJLabel("S_G2",""),gbc);
        panel4.add(new BaseJLabel("S_KL2",""),gbc);
        panel4.add(new BaseJLabel("S_G1",""),gbc);
        panel4.add(new BaseJLabel("S_KL1",""),gbc);*/


        mainFrame.add(panel1);
        mainFrame.add(panel2);
        mainFrame.add(panel3);
      /*  mainFrame.add(panel3);
        mainFrame.add(panel4);*/
        mainFrame.setVisible(true);


        //["board",{"data":{"id":3220,"sym":"CTG","lastPrice":19.95,"lastVol":0,"cl":"d","change":"0.25","changePc":"1.24","totalVol":142661,"time":"null","hp":20.3,"ch":"i","lp":20,"lc":"d","ap":20.1,"ca":"d","timeServer":"14:34:27"}}]
        //["board",{"data":{"id":3210,"sym":"FLC","side":"S","g1":"ATC|19340|e","g2":"3.73|100|d","g3":"3.74|6810|d","vol4":0,"timeServer":"14:34:40"}}]
    }

    public void updateStatus(String status , String cl){

        lbStatus.setText("wss : " + status + "  ");
        lbStatus.setForeground(Color.decode(UtilsColor.getcolor(cl)));
    }

    public void  updateDataLastValue(String value){
        try {
            JSONObject jsonObjectMain = new JSONObject(value);
            if (jsonObjectMain.has("data")){
                JSONObject jsonObjectData = jsonObjectMain.getJSONObject("data");
                if (jsonObjectData.has("id")){
                    if (jsonObjectData.getLong("id")==3220) {
                        if (jsonObjectData.getString("sym").equals("FLC")) {

                            panel2.setBackground(Color.YELLOW);
                            try {
                                lbPrice.setText(String.valueOf(jsonObjectData.getDouble("lastPrice")));
                                lbPrice.setForeground(Color.decode(UtilsColor.getcolor(jsonObjectData.getString("cl"))));
                            }
                            catch (Exception e){
                                e.printStackTrace();
                            }

                            try {

                                lbLastVolume.setText(UtilsFormat.formatMoney(String.valueOf(jsonObjectData.getLong("lastVol"))));
                                lbLastVolume.setForeground(Color.decode(UtilsColor.getcolor(jsonObjectData.getString("cl"))));
                            }
                            catch (Exception e){
                                e.printStackTrace();
                            }

                            try {
                                lbOT.setText(String.valueOf(jsonObjectData.getDouble("change")));
                                lbOT.setForeground(Color.decode(UtilsColor.getcolor(jsonObjectData.getString("cl"))));
                            }
                            catch (Exception e){
                                e.printStackTrace();
                            }



                            lbSym.setForeground(Color.decode(UtilsColor.getcolor(jsonObjectData.getString("cl"))));

                            try
                            {
                                Thread.sleep(2000);
                                panel2.setBackground(Color.decode("#00000000"));
                            }
                            catch(InterruptedException ex)
                            {
                                Thread.currentThread().interrupt();
                            }

                        }
                    }
                }
            }
        }
        catch (Exception e){

        }
    }
}
