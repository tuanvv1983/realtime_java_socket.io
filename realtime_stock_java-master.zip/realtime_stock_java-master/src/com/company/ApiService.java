package com.company;

import com.company.model.StockData;

import retrofit2.Call;
import retrofit2.http.GET;

import java.util.List;

public interface ApiService {
    @GET("getliststockdata/FLC")
    Call<List<StockData>> getStockList();
}
