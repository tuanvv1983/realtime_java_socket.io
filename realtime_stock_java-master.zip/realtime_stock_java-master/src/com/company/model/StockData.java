package com.company.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StockData  {


        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("sym")
        @Expose
        private String sym;
        @SerializedName("mc")
        @Expose
        private String mc;
        @SerializedName("c")
        @Expose
        private Double c;
        @SerializedName("f")
        @Expose
        private Double f;
        @SerializedName("r")
        @Expose
        private Double r;
        @SerializedName("lastPrice")
        @Expose
        private Double lastPrice;
        @SerializedName("lastVolume")
        @Expose
        private Integer lastVolume;
        @SerializedName("lot")
        @Expose
        private Integer lot;
        @SerializedName("ot")
        @Expose
        private String ot;
        @SerializedName("changePc")
        @Expose
        private String changePc;
        @SerializedName("avePrice")
        @Expose
        private String avePrice;
        @SerializedName("highPrice")
        @Expose
        private String highPrice;
        @SerializedName("lowPrice")
        @Expose
        private String lowPrice;
        @SerializedName("fBVol")
        @Expose
        private String fBVol;
        @SerializedName("fBValue")
        @Expose
        private String fBValue;
        @SerializedName("fSVolume")
        @Expose
        private String fSVolume;
        @SerializedName("fSValue")
        @Expose
        private String fSValue;
        @SerializedName("fRoom")
        @Expose
        private String fRoom;
        @SerializedName("g1")
        @Expose
        private String g1;
        @SerializedName("g2")
        @Expose
        private String g2;
        @SerializedName("g3")
        @Expose
        private String g3;
        @SerializedName("g4")
        @Expose
        private String g4;
        @SerializedName("g5")
        @Expose
        private String g5;
        @SerializedName("g6")
        @Expose
        private String g6;
        @SerializedName("g7")
        @Expose
        private String g7;
        @SerializedName("mp")
        @Expose
        private String mp;

        private String cl;

    public String getCl() {
        if (lastPrice.doubleValue()==0){
            return "e";
        }
        double value = lastPrice.doubleValue() - r.doubleValue();
        if (value > 0){
            return "i";
        }
        else {
            if (value < 0){
                return "d";
            }
            else {
                return "e";
            }
        }
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getSym() {
            return sym;
        }

        public void setSym(String sym) {
            this.sym = sym;
        }

        public String getMc() {
            return mc;
        }

        public void setMc(String mc) {
            this.mc = mc;
        }

        public Double getC() {
            return c;
        }

        public void setC(Double c) {
            this.c = c;
        }

        public Double getF() {
            return f;
        }

        public void setF(Double f) {
            this.f = f;
        }

        public Double getR() {
            return r;
        }

        public void setR(Double r) {
            this.r = r;
        }

        public Double getLastPrice() {
            return lastPrice;
        }

        public void setLastPrice(Double lastPrice) {
            this.lastPrice = lastPrice;
        }

        public Integer getLastVolume() {
            return lastVolume;
        }

        public void setLastVolume(Integer lastVolume) {
            this.lastVolume = lastVolume;
        }

        public Integer getLot() {
            return lot;
        }

        public void setLot(Integer lot) {
            this.lot = lot;
        }

        public String getOt() {
            return ot;
        }

        public void setOt(String ot) {
            this.ot = ot;
        }

        public String getChangePc() {
            return changePc;
        }

        public void setChangePc(String changePc) {
            this.changePc = changePc;
        }

        public String getAvePrice() {
            return avePrice;
        }

        public void setAvePrice(String avePrice) {
            this.avePrice = avePrice;
        }

        public String getHighPrice() {
            return highPrice;
        }

        public void setHighPrice(String highPrice) {
            this.highPrice = highPrice;
        }

        public String getLowPrice() {
            return lowPrice;
        }

        public void setLowPrice(String lowPrice) {
            this.lowPrice = lowPrice;
        }

        public String getFBVol() {
            return fBVol;
        }

        public void setFBVol(String fBVol) {
            this.fBVol = fBVol;
        }

        public String getFBValue() {
            return fBValue;
        }

        public void setFBValue(String fBValue) {
            this.fBValue = fBValue;
        }

        public String getFSVolume() {
            return fSVolume;
        }

        public void setFSVolume(String fSVolume) {
            this.fSVolume = fSVolume;
        }

        public String getFSValue() {
            return fSValue;
        }

        public void setFSValue(String fSValue) {
            this.fSValue = fSValue;
        }

        public String getFRoom() {
            return fRoom;
        }

        public void setFRoom(String fRoom) {
            this.fRoom = fRoom;
        }

        public String getG1() {
            return g1;
        }

        public void setG1(String g1) {
            this.g1 = g1;
        }

        public String getG2() {
            return g2;
        }

        public void setG2(String g2) {
            this.g2 = g2;
        }

        public String getG3() {
            return g3;
        }

        public void setG3(String g3) {
            this.g3 = g3;
        }

        public String getG4() {
            return g4;
        }

        public void setG4(String g4) {
            this.g4 = g4;
        }

        public String getG5() {
            return g5;
        }

        public void setG5(String g5) {
            this.g5 = g5;
        }

        public String getG6() {
            return g6;
        }

        public void setG6(String g6) {
            this.g6 = g6;
        }

        public String getG7() {
            return g7;
        }

        public void setG7(String g7) {
            this.g7 = g7;
        }

        public String getMp() {
            return mp;
        }

        public void setMp(String mp) {
            this.mp = mp;
        }

    }

